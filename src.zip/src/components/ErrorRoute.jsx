function ErrorRoute() {
  return (
    <div>
      Error in url
    </div>
  )
}

export default ErrorRoute
